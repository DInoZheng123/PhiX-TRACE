# Data dictionary

## User input

- `user_input/candidate_genomes.fasta`: replaceable multi-FASTA file containing new PhiX174-compatible candidate genomes.

## Frozen resources

- `reference/NC_001422_1.fna`: PhiX174 NC_001422.1 reference FASTA.
- `reference/NC_001422.1_pseudocircular.gff`: pseudocircular CDS annotation used for coding masks, critical proteins and architecture calculations.
- `data/phix_trace_snv_oof_predictions.csv.gz`: released 16,098-row SNV prediction lookup.
- `data/science302_frozen_component_reference.csv.gz`: frozen raw component distributions and reference percentiles for the 302-candidate cohort.
- `data/aa_residue_genome_map.csv.gz`: amino-acid residue to circular genome-coordinate map.
- `source_data/phix_all_dms100_sub_libraries_normalized_unique_stat_1nt.tsv.zip`: original Wei nucleotide-fitness data used to reconstruct the DMS reference.
- `source_data/phix_proteome_dms_mut_Fitness_unique_advanced.tsv.zip`: original Wei amino-acid fitness data used for exact event matching.
- `publication_assets/Figure_1/Fig1_PhiX_TRACE_workflow_v7.pdf`: final author-approved v7 method schematic.
- `publication_assets/Figure_1/Fig1_PhiX_TRACE_workflow_v7.png`: notebook-display copy of the final v7 method schematic.

## Main output fields

- `candidate_rank_within_input`: rank among records in the submitted FASTA.
- `candidate_id`: unique FASTA identifier.
- `coding_event_fitness`: raw `C` component.
- `noncoding_fitness`: raw `N` component.
- `critical_protein_integrity_score`: raw `P` component.
- `noncoding_integrity_score`: raw `R` component.
- `architecture_integrity_score`: raw `A` component.
- `C_percentile`, `N_percentile`, `P_percentile`, `R_percentile`, `A_percentile`: component percentiles frozen against the Science-302 cohort.
- `*_weighted_contribution`: component percentile multiplied by its fixed weight.
- `component_weight_available`: sum of weights for nonmissing components.
- `genome_score`: availability-renormalized weighted score.
- `score_status`: `PASS`, `PASS_WITH_DMS_REFERENCE_GAP`, or a partial status requiring review.
- `complete_score_valid`: 1 only for statuses beginning with `PASS`.

Coverage and edit-count fields are retained so users can audit how much of each sequence was supported by the released evidence.
