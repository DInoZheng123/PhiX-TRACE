# FASTA scorer validation

The scorer was regression-tested on all 302 released candidate records.

- `C` maximum absolute difference: 2.22 × 10⁻¹⁶.
- `N` maximum absolute difference on nonmissing rows: 0.
- `P` maximum absolute difference: 3.33 × 10⁻¹⁶.
- `R` maximum absolute difference: 1.11 × 10⁻¹⁶.
- `A` maximum absolute difference: 5.55 × 10⁻¹⁶.
- Final-score maximum absolute difference: 2.22 × 10⁻¹⁶.
- All 302 input-local ranks matched exactly.

The underlying released formal ranking had AUROC 0.9464597902, average precision 0.6146986221, 7 confirmed recoveries among the top 10 candidates and a last confirmed recovery at rank 79.

These checks establish numerical agreement with the released workflow on the retrospective cohort. They do not establish prospective biological performance for new designs.

The notebook and documentation were synchronized with the final v7 component definitions and fixed weights. This lightweight package scores user FASTA files only; regeneration of final v7 Figures 2–4 and Tables 1–4 belongs to the full reproduction package.
