# Software, data and citation notes

The experimental nucleotide and amino-acid fitness landscapes are from Wei H, Li X and Lehner B, DOI https://doi.org/10.64898/2026.07.25.740675, repository https://github.com/lehner-lab/phix174_WGM. The raw sequencing accession reported by the authors is PRJEB120835.

The 302 generated genomes and wet-lab recovery outcomes are from King SH et al., *Science*, DOI https://doi.org/10.1126/science.aec2657. The generation workflow is available at https://github.com/ArcInstitute/evo2/tree/main/phage_gen. Evo 2 code is available at https://github.com/ArcInstitute/evo2.

The Evo 1 sensitivity analysis uses the official `evo-model` software and the `evo-1-8k-base` checkpoint to calculate summed joint sequence log likelihoods for matched 512-nt reference and mutant windows. Evo 1: Nguyen E et al., *Science* (2024), DOI https://doi.org/10.1126/science.ado9336. Code: https://github.com/evo-design/evo. The GPU environment pins `evo-model==0.5`.

FoldX 5.0 Linux produced the distributed stability summaries. The executable is not redistributed and requires a FoldX licence. See https://foldxsuite.crg.eu/ and Delgado J et al., *Bioinformatics* 35, 4168–4169 (2019), https://doi.org/10.1093/bioinformatics/btz184.

AlphaFold-derived features were generated through ColabFold. See Jumper J et al., *Nature* 596, 583–589 (2021), https://doi.org/10.1038/s41586-021-03819-2; Mirdita M et al., *Nature Methods* 19, 679–682 (2022), https://doi.org/10.1038/s41592-022-01488-1; https://github.com/google-deepmind/alphafold; and https://github.com/sokrypton/ColabFold.

Explainable Boosting Machines are implemented with InterpretML: https://github.com/interpretml/interpret. Numerical analysis uses NumPy, pandas, SciPy and scikit-learn; model serialization uses joblib; plotting uses Matplotlib. Exact versions are pinned in `requirements.txt`.
