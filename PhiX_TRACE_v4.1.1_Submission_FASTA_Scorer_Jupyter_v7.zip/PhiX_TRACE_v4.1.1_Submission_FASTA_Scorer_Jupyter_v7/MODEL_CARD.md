# Model card

## Intended use

This package prioritizes PhiX174-compatible candidate genomes for experimental review. It calculates the five released PhiX-TRACE components and a cohort-referenced genome score from a FASTA sequence.

## Inputs

Each sequence must be a 5,386-nt, forward-orientation PhiX174 candidate with the same coordinate origin as NC_001422.1. Multiple uniquely named records may be supplied in one FASTA file.

## Components

- `C`: coding-event fitness from exact Wei amino-acid measurements when available, with released SNV predictions used for remaining supported coding substitutions.
- `N`: released SNV predictions for supported noncoding substitutions.
- `P`: integrity of seven critical translated proteins relative to the reference.
- `R`: integrity across the 206 reference noncoding sites.
- `A`: circular start/stop architecture integrity relative to the released reference pattern.

Raw components are converted to percentiles frozen on the original Science-302 cohort and combined with weights 0.45, 0.15, 0.25, 0.10 and 0.05, respectively.

This component definition and weighting are synchronized with the final v7 workflow figure included in `publication_assets/Figure_1/`.

## Validation

The FASTA implementation was regression-tested on all 302 released candidates. Raw components, final scores and ranks matched the released candidate workflow within floating-point precision. This confirms implementation agreement on the released cohort; it is not independent prospective biological validation.

## Limitations

The model is PhiX174-specific, is based mainly on single-mutation evidence and does not explicitly learn higher-order epistasis. Indels, ambiguous bases, length changes and reference-coordinate mismatches are outside the complete-score validation domain. A partial score may be emitted for auditability, but it must not be treated as fully validated. The score is not a calibrated viability probability.

The formal released model excludes Evo 1. Evo 1 was evaluated separately as a sensitivity analysis in the full reproduction package.
