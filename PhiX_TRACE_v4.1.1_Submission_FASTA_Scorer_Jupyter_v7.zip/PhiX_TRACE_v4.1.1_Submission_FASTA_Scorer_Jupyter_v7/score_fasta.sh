#!/usr/bin/env bash
set -euo pipefail

project_dir="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$project_dir"

input_fasta="${1:-user_input/candidate_genomes.fasta}"
python scripts/score_user_fasta_complete.py \
  --fasta "$input_fasta" \
  --output-dir user_output
