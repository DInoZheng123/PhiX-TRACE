#!/usr/bin/env python3
"""Compute the complete five-component PhiX-TRACE score for new FASTA records.

The score is specific to PhiX174 NC_001422.1-compatible genomes. Raw components
are converted to percentiles against the frozen Science-302 reference cohort,
so adding or removing user sequences does not change previously reported scores.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import math
import re
from collections import defaultdict
from pathlib import Path

import edlib
import numpy as np
import pandas as pd
from scipy.ndimage import gaussian_filter1d

from annotate_candidate_aa import (
    CODON_TABLE,
    aligned_maps,
    build_codon_map,
    build_dms_reference,
    event_ids,
    normalize_aa_table,
    read_fasta,
)


ROOT = Path(__file__).resolve().parents[1]
GENOME_LENGTH = 5386

PHIX174_GENE_BY_FEATURE = {
    "NC_001422.1_ORF.1": "C",
    "NC_001422.1_ORF.2": "E",
    "NC_001422.1_ORF.3": "G",
    "NC_001422.1_ORF.9": "A*",
    "NC_001422.1_ORF.11": "J",
    "NC_001422.1_ORF.12": "F",
    "NC_001422.1_ORF.14": "B",
    "NC_001422.1_ORF.15": "K",
    "NC_001422.1_ORF.16": "D",
    "NC_001422.1_ORF.22": "H",
    "NC_001422.1_ORF.23": "A",
}

CRITICAL_GENE_WEIGHT = {
    "A": 1.5,
    "A*": 1.5,
    "F": 1.5,
    "G": 1.5,
    "H": 1.5,
    "C": 1.4,
    "J": 1.4,
}

COMPONENTS = [
    ("coding_event_fitness", "C", 0.45),
    ("noncoding_fitness", "N", 0.15),
    ("critical_protein_integrity_score", "P", 0.25),
    ("noncoding_integrity_score", "R", 0.10),
    ("architecture_integrity_score", "A", 0.05),
]

TRUTH_INDICES = {
    "genome": [3980, 4496, 5074, 50, 132, 389, 567, 847, 1000, 2394, 2930,
               133, 133, 48, 218, 390, 845, 840, 961, 2281, 2919, 3914],
    "aabkc": [3980, 4496, 5074, 50, 132, 133, 133, 48, 218, 390],
    "de": [389, 567, 845, 840],
    "j": [847, 961],
    "f": [1000, 2281],
    "g": [2394, 2919],
    "h": [2930, 3914],
}


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def translate_nt(sequence: str) -> str:
    usable = sequence[: len(sequence) - len(sequence) % 3]
    return "".join(CODON_TABLE.get(usable[index:index + 3], "X") for index in range(0, len(usable), 3))


def parse_gff(path: Path) -> tuple[list[dict], str]:
    features: list[dict] = []
    fasta_parts: list[str] = []
    in_fasta = False
    for raw in path.read_text(encoding="utf-8").splitlines():
        if raw == "##FASTA":
            in_fasta = True
            continue
        if in_fasta:
            if not raw.startswith(">"):
                fasta_parts.append(raw.strip())
            continue
        if not raw or raw.startswith("#"):
            continue
        fields = raw.split("\t")
        if len(fields) < 9 or fields[2] != "CDS":
            continue
        attributes = {}
        for item in fields[8].split(";"):
            if "=" in item:
                key, value = item.split("=", 1)
                attributes[key] = value
        feature_id = attributes.get("ID", f"CDS_{len(features) + 1}")
        # The Science/orfipy file serializes zero-based, half-open coordinates.
        features.append({
            "feature_id": feature_id,
            "gene": PHIX174_GENE_BY_FEATURE.get(feature_id, feature_id),
            "product": attributes.get("product", feature_id),
            "start": int(fields[3]) + 1,
            "end": int(fields[4]),
        })
    return features, "".join(fasta_parts).upper()


def aligned_strings(reference: str, candidate: str) -> tuple[str, str, int]:
    result = edlib.align(reference, candidate, mode="NW", task="path")
    nice = edlib.getNiceAlignment(result, reference, candidate)
    return nice["query_aligned"], nice["target_aligned"], int(result["editDistance"])


def collect_variants(reference_alignment: str, candidate_alignment: str, coding_mask: set[int]) -> list[dict]:
    variants: list[dict] = []
    reference_position = 0
    insertion_index = 0
    for reference_base, alternate_base in zip(reference_alignment, candidate_alignment):
        if reference_base != "-":
            reference_position += 1
            insertion_index = 0
        if reference_base == alternate_base:
            continue
        if reference_base == "-":
            insertion_index += 1
            variant_type = "insertion"
        elif alternate_base == "-":
            variant_type = "deletion"
        else:
            variant_type = "snv"
        variants.append({
            "position": reference_position,
            "ref": reference_base,
            "alt": alternate_base,
            "variant_type": variant_type,
            "insertion_index": insertion_index,
            "is_coding": int(reference_position in coding_mask),
        })
    return variants


def protein_identity(reference: str, candidate: str) -> float:
    if not reference or not candidate:
        return 0.0
    distance = int(edlib.align(reference, candidate, mode="NW", task="distance")["editDistance"])
    return max(0.0, 1.0 - distance / max(len(reference), len(candidate), 1))


def find_circular_forward_orfs(sequence: str, min_nt: int = 90, max_nt: int = 1800) -> list[dict]:
    sequence = sequence.upper()
    length = len(sequence)
    doubled = sequence + sequence[: max_nt + 3]
    output: list[dict] = []
    for start in range(length):
        if doubled[start:start + 3] != "ATG":
            continue
        for offset in range(3, max_nt + 1, 3):
            codon = doubled[start + offset:start + offset + 3]
            if len(codon) < 3:
                break
            if codon in {"TAA", "TGA", "TAG"}:
                total = offset + 3
                if total >= min_nt:
                    nucleotide = doubled[start:start + total]
                    output.append({"protein": translate_nt(nucleotide).rstrip("*")})
                break
    return output


def best_orf_integrity(reference_protein: str, orfs: list[dict]) -> float:
    reference = reference_protein.rstrip("*")
    best = 0.0
    for item in orfs:
        candidate = item["protein"]
        ratio = len(candidate) / max(len(reference), 1)
        if not 0.45 <= ratio <= 1.75:
            continue
        score = protein_identity(reference, candidate) * math.exp(-abs(math.log(max(ratio, 1e-6))))
        best = max(best, score)
    return float(np.clip(best, 0.0, 1.0))


def start_stop_vector(sequence: str) -> np.ndarray:
    sequence = sequence.upper()
    extended = sequence + sequence[:2]
    return np.fromiter(
        (extended[index:index + 3] in {"ATG", "TAA", "TAG", "TGA"} for index in range(len(sequence))),
        dtype=float,
        count=len(sequence),
    )


def circular_max_dot(truth: np.ndarray, observed: np.ndarray) -> float:
    length = len(observed)
    if len(truth) < length:
        truth = np.pad(truth, (0, length - len(truth)))
    else:
        truth = truth[:length]
    correlation = np.fft.ifft(np.conj(np.fft.fft(truth)) * np.fft.fft(observed)).real
    return float(np.max(correlation))


def architecture_setup(reference: str) -> tuple[np.ndarray, np.ndarray]:
    matrix = np.zeros((len(TRUTH_INDICES), GENOME_LENGTH), dtype=float)
    for row, indices in enumerate(TRUTH_INDICES.values()):
        for index in indices:
            matrix[row, index] = 1.0
    blurred = np.vstack([gaussian_filter1d(row, sigma=5.0) for row in matrix])
    blurred[matrix.astype(bool)] = 1.0
    reference_vector = start_stop_vector(reference)
    normalizers = np.asarray([circular_max_dot(row, reference_vector) for row in blurred])
    return blurred, normalizers


def architecture_scores(sequence: str, truth: np.ndarray, normalizers: np.ndarray) -> tuple[float, float]:
    observed = start_stop_vector(sequence)
    values = np.asarray([circular_max_dot(row, observed) for row in truth])
    scores = np.divide(values, normalizers, out=np.full_like(values, np.nan), where=normalizers > 0)
    genome_score = float(scores[0])
    integrity = math.exp(-abs(math.log(max(genome_score, 1e-12))))
    return genome_score, integrity


def aggregate_fitness(values) -> float:
    array = pd.to_numeric(pd.Series(values), errors="coerce").dropna().to_numpy(float)
    if not len(array):
        return np.nan
    scaled = np.clip((array + 0.5) / 1.75, 0.0, 1.0)
    return float(0.50 * np.quantile(scaled, 0.10) + 0.30 * scaled.mean() + 0.20 * scaled.min())


def frozen_percentile(
    value: float,
    reference_values: pd.Series,
    reference_percentiles: pd.Series | None = None,
) -> float:
    table = pd.DataFrame({"value": pd.to_numeric(reference_values, errors="coerce")})
    if reference_percentiles is None:
        table["percentile"] = table["value"].rank(method="average", pct=True)
    else:
        table["percentile"] = pd.to_numeric(reference_percentiles, errors="coerce")
    table = table.dropna().sort_values("value")
    values = table["value"].to_numpy(float)
    percentiles_by_row = table["percentile"].to_numpy(float)
    if not len(values) or not np.isfinite(value):
        return np.nan
    nearest = int(np.argmin(np.abs(values - value)))
    if np.isclose(values[nearest], value, rtol=1e-12, atol=1e-12):
        exact = values == values[nearest]
        return float(np.mean(percentiles_by_row[exact]))
    grouped = table.groupby("value", as_index=False)["percentile"].mean()
    unique = grouped["value"].to_numpy(float)
    percentiles = grouped["percentile"].to_numpy(float)
    return float(np.interp(value, unique, percentiles, left=percentiles[0], right=percentiles[-1]))


def prepare_reference_proteins(features: list[dict], pseudo_reference: str) -> dict[str, str]:
    proteins = {}
    for feature in features:
        nucleotide = pseudo_reference[feature["start"] - 1:feature["end"]]
        proteins[feature["feature_id"]] = translate_nt(nucleotide)
    return proteins


def measured_aa_events(
    sequence: str,
    ncbi_reference: str,
    codons: pd.DataFrame,
    aa_lookup: pd.DataFrame,
) -> tuple[list[float], set[int], int]:
    bases, indices, _ = aligned_maps(ncbi_reference, sequence)
    gene_starts = {
        gene: tuple(int(value) for value in block.loc[block["aa_mut_pos"].idxmin(), "codon_positions"].split(","))[0]
        for gene, block in codons.groupby("aa_mut_gene", sort=False)
    }
    rows = []
    unsupported = 0
    for row in codons.itertuples(index=False):
        positions = tuple(int(value) for value in row.codon_positions.split(","))
        if any(position not in indices or bases.get(position) not in "ACGT" for position in positions):
            unsupported += 1
            continue
        candidate_indices = [indices[position] for position in positions]
        for index in range(1, len(candidate_indices)):
            while candidate_indices[index] <= candidate_indices[index - 1]:
                candidate_indices[index] += len(sequence)
        start_index = indices.get(gene_starts[row.aa_mut_gene])
        if start_index is None or np.diff(candidate_indices).tolist() != [1, 1]:
            unsupported += 1
            continue
        while candidate_indices[0] < start_index:
            candidate_indices[0] += len(sequence)
        if (candidate_indices[0] - start_index) % 3:
            unsupported += 1
            continue
        candidate_codon = "".join(bases[position] for position in positions)
        alternate = CODON_TABLE.get(candidate_codon, "X")
        if alternate == row.aa_mut_wt:
            continue
        mutation_id = f"gp{row.aa_mut_gene}_{row.aa_mut_wt}{row.aa_mut_pos}{alternate}"
        if mutation_id not in aa_lookup.index:
            unsupported += 1
            continue
        measured = aa_lookup.loc[mutation_id]
        rows.append({
            "aa_mut_ID": mutation_id,
            "codon_positions": row.codon_positions,
            "fitness": float(measured["fitness_aa_mut"]),
        })
    if not rows:
        return [], set(), unsupported
    consequences = pd.DataFrame(rows).drop_duplicates(["aa_mut_ID", "codon_positions"])
    consequences["event"] = event_ids(consequences)
    event_fitness = consequences.groupby("event")["fitness"].min().astype(float).tolist()
    covered = {int(position) for text in consequences.codon_positions for position in str(text).split(",")}
    return event_fitness, covered, unsupported


def main() -> None:
    parser = argparse.ArgumentParser(description="Score new PhiX174 FASTA records with complete C/N/P/R/A evidence")
    parser.add_argument("--fasta", type=Path, default=ROOT / "user_input" / "candidate_genomes.fasta")
    parser.add_argument("--output-dir", type=Path, default=ROOT / "user_output")
    parser.add_argument("--reference", type=Path, default=ROOT / "reference" / "NC_001422_1.fna")
    parser.add_argument("--gff", type=Path, default=ROOT / "reference" / "NC_001422.1_pseudocircular.gff")
    parser.add_argument("--snv-predictions", type=Path, default=ROOT / "data" / "phix_trace_snv_oof_predictions.csv.gz")
    parser.add_argument("--calibration-components", type=Path, default=ROOT / "data" / "science302_frozen_component_reference.csv.gz")
    parser.add_argument("--build-reference-components", action="store_true")
    args = parser.parse_args()

    reference = read_fasta(args.reference)[0][1]
    if len(reference) != GENOME_LENGTH:
        raise RuntimeError("This scorer is locked to the 5,386-nt PhiX174 NC_001422.1 reference")
    features, pseudo_reference = parse_gff(args.gff)
    if not pseudo_reference:
        pseudo_reference = reference + reference[:136]
    reference_proteins = prepare_reference_proteins(features, pseudo_reference)
    legacy_coding_mask: set[int] = set()
    circular_coding_mask: set[int] = set()
    for feature in features:
        legacy_coding_mask.update(range(feature["start"], min(feature["end"], GENOME_LENGTH) + 1))
        for pseudo_position in range(feature["start"], feature["end"] + 1):
            circular_coding_mask.add((pseudo_position - 1) % GENOME_LENGTH + 1)
    noncoding_reference_sites = GENOME_LENGTH - len(legacy_coding_mask)
    if noncoding_reference_sites != 206:
        raise RuntimeError(f"Expected 206 locked noncoding reference sites, found {noncoding_reference_sites}")

    snv_lookup = pd.read_csv(args.snv_predictions)
    if len(snv_lookup) != 16098 or snv_lookup.variant_id.duplicated().any():
        raise RuntimeError("Expected a complete 16,098-row frozen SNV lookup")
    snv_lookup = snv_lookup.set_index("variant_id")

    snv_source = ROOT / "source_data" / "phix_all_dms100_sub_libraries_normalized_unique_stat_1nt.tsv.zip"
    aa_source = ROOT / "source_data" / "phix_proteome_dms_mut_Fitness_unique_advanced.tsv.zip"
    dms_reference, reference_differences = build_dms_reference(reference, snv_source)
    aa = normalize_aa_table(aa_source)
    aa_lookup = aa.set_index("aa_mut_ID")
    codons = build_codon_map(ROOT / "data" / "aa_residue_genome_map.csv.gz", aa, dms_reference)
    truth, normalizers = architecture_setup(reference)

    rows = []
    detail_rows = []
    for candidate_id, sequence in read_fasta(args.fasta):
        invalid = sorted(set(sequence) - set("ACGTN"))
        if invalid:
            raise RuntimeError(f"{candidate_id} contains unsupported characters: {invalid}")
        reference_alignment, candidate_alignment, edit_distance = aligned_strings(reference, sequence)
        variants = collect_variants(reference_alignment, candidate_alignment, circular_coding_mask)
        candidate_snvs = [item for item in variants if item["variant_type"] == "snv" and item["alt"] in "ACGT"]
        snvs = []
        unmatched_snvs = 0
        unsupported_edits = sum(item["variant_type"] != "snv" or item["alt"] not in "ACGT" for item in variants)
        for item in candidate_snvs:
            variant_id = f"{item['ref']}{item['position']}{item['alt']}"
            if variant_id not in snv_lookup.index:
                # Twenty NC_001422.1/DMS-reference discrepancies create a small
                # set of substitutions without a compatible Wei-model row. The
                # formal Science-302 workflow excludes these with the same rule.
                unmatched_snvs += 1
                continue
            item["variant_id"] = variant_id
            item["prediction"] = float(snv_lookup.loc[variant_id, "ensemble_prediction"])
            snvs.append(item)

        experimental_values, covered_positions, unsupported_residues = measured_aa_events(
            sequence, reference, codons, aa_lookup
        )
        remaining_coding = [
            item["prediction"] for item in snvs
            if item["is_coding"] and item["position"] not in covered_positions
        ]
        noncoding_predictions = [item["prediction"] for item in snvs if not item["is_coding"]]
        coding_score = aggregate_fitness(experimental_values + remaining_coding)
        noncoding_score = aggregate_fitness(noncoding_predictions)

        orfs = find_circular_forward_orfs(sequence)
        critical_values = []
        critical_weights = []
        for feature in features:
            gene = feature["gene"]
            if gene not in CRITICAL_GENE_WEIGHT:
                continue
            integrity = best_orf_integrity(reference_proteins[feature["feature_id"]], orfs)
            critical_values.append(integrity)
            critical_weights.append(CRITICAL_GENE_WEIGHT[gene])
        if len(critical_values) != 7:
            raise RuntimeError(f"Expected seven critical proteins, found {len(critical_values)}")
        protein_score = 0.65 * float(np.average(critical_values, weights=critical_weights)) + 0.35 * float(np.min(critical_values))

        noncoding_changes = sum(item["position"] not in legacy_coding_mask for item in variants)
        noncoding_integrity = math.exp(-3.0 * noncoding_changes / noncoding_reference_sites)
        architecture_genome, architecture_integrity = architecture_scores(sequence, truth, normalizers)
        if len(sequence) != GENOME_LENGTH or unsupported_edits:
            status = "PARTIAL_NON_SNV_OR_LENGTH_CHANGE"
        elif unmatched_snvs:
            status = "PASS_WITH_DMS_REFERENCE_GAP"
        else:
            status = "PASS"
        row = {
            "candidate_id": candidate_id,
            "candidate_length": len(sequence),
            "edit_distance_to_reference": edit_distance,
            "supported_snv_count": len(snvs),
            "unmatched_snv_count": unmatched_snvs,
            "unsupported_indel_or_ambiguous_edit_count": unsupported_edits,
            "experimental_aa_event_count": len(experimental_values),
            "remaining_coding_snv_count": len(remaining_coding),
            "noncoding_snv_count": len(noncoding_predictions),
            "unsupported_or_frame_disrupted_residues": unsupported_residues,
            "coding_event_fitness": coding_score,
            "noncoding_fitness": noncoding_score,
            "critical_protein_integrity_score": protein_score,
            "critical_protein_weakest_integrity": float(np.min(critical_values)),
            "critical_protein_count": len(critical_values),
            "noncoding_change_count": noncoding_changes,
            "noncoding_integrity_score": noncoding_integrity,
            "science_architecture_genome_score": architecture_genome,
            "architecture_integrity_score": architecture_integrity,
            "score_status": status,
            "complete_score_valid": int(status.startswith("PASS")),
        }
        rows.append(row)
        for item in snvs:
            detail_rows.append({"candidate_id": candidate_id, **item})

    output = pd.DataFrame(rows)
    args.output_dir.mkdir(parents=True, exist_ok=True)
    raw_path = args.output_dir / "candidate_complete_raw_components.csv"
    output.to_csv(raw_path, index=False)

    if args.build_reference_components:
        print(f"PHIX_TRACE_COMPLETE_COMPONENT_BUILD_PASS candidates={len(output)} output={raw_path}")
        return
    if not args.calibration_components.exists():
        raise RuntimeError(
            f"Frozen Science-302 calibration table is missing: {args.calibration_components}"
        )
    calibration = pd.read_csv(args.calibration_components)
    if len(calibration) != 302:
        raise RuntimeError("Frozen calibration table must contain exactly 302 Science candidates")
    for column, short_name, weight in COMPONENTS:
        percentile_column = f"{short_name}_reference_percentile"
        output[f"{short_name}_percentile"] = output[column].map(
            lambda value: frozen_percentile(
                float(value),
                calibration[column],
                calibration[percentile_column] if percentile_column in calibration else None,
            )
        )
        output[f"{short_name}_weighted_contribution"] = weight * output[f"{short_name}_percentile"]
    numerator = np.zeros(len(output), dtype=float)
    denominator = np.zeros(len(output), dtype=float)
    for _, short_name, weight in COMPONENTS:
        percentile = output[f"{short_name}_percentile"]
        present = percentile.notna().to_numpy()
        numerator[present] += weight * percentile.loc[present].to_numpy(float)
        denominator[present] += weight
    output["component_weight_available"] = denominator
    output["genome_score"] = np.divide(
        numerator, denominator, out=np.full(len(output), np.nan), where=denominator > 0
    )
    output = output.sort_values(["genome_score", "candidate_id"], ascending=[False, True], kind="mergesort").reset_index(drop=True)
    output.insert(0, "candidate_rank_within_input", np.arange(1, len(output) + 1))
    score_path = args.output_dir / "candidate_complete_scores.csv"
    detail_path = args.output_dir / "candidate_complete_snv_details.csv.gz"
    output.to_csv(score_path, index=False)
    pd.DataFrame(detail_rows).to_csv(detail_path, index=False, compression="gzip")

    audit = {
        "status": "PASS",
        "scope": "PhiX174 NC_001422.1-compatible candidates only",
        "candidate_count": len(output),
        "complete_pass_count": int(output.score_status.str.startswith("PASS").sum()),
        "score_definition": (
            "Availability-renormalized 0.45*C + 0.15*N + 0.25*P + 0.10*R + 0.05*A "
            "after frozen Science-302 percentile calibration"
        ),
        "percentile_policy": "Linear interpolation of average-rank percentiles frozen on the original Science-302 cohort",
        "noncoding_reference_sites": noncoding_reference_sites,
        "reference_differences_ncbi_vs_dms": reference_differences,
        "inputs": {
            "fasta": str(args.fasta),
            "fasta_sha256": sha256(args.fasta),
            "reference": str(args.reference),
            "gff": str(args.gff),
            "snv_predictions": str(args.snv_predictions),
            "calibration_components": str(args.calibration_components),
        },
        "important_boundary": (
            "Complete scores are valid only for same-origin, forward-orientation, 5,386-nt PhiX174-compatible genomes. "
            "Rows marked PARTIAL contain unsupported indels, ambiguous bases or length changes and require manual review."
        ),
    }
    (args.output_dir / "complete_scoring_audit.json").write_text(json.dumps(audit, indent=2) + "\n", encoding="utf-8")
    print(f"PHIX_TRACE_COMPLETE_FASTA_PASS candidates={len(output)} output={score_path}")


if __name__ == "__main__":
    main()
