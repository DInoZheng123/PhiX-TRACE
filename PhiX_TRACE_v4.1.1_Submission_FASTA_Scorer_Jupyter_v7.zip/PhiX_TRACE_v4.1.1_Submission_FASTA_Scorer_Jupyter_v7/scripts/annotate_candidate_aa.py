#!/usr/bin/env python3
"""Annotate candidate FASTA files with experimentally measured AA effects."""

from __future__ import annotations

import argparse
import itertools
import json
import re
import zipfile
from collections import defaultdict
from io import TextIOWrapper
from pathlib import Path

import edlib
import numpy as np
import pandas as pd


GENOME_LENGTH = 5386
CODON_TABLE = {
    "TTT": "F", "TTC": "F", "TTA": "L", "TTG": "L",
    "TCT": "S", "TCC": "S", "TCA": "S", "TCG": "S",
    "TAT": "Y", "TAC": "Y", "TAA": "*", "TAG": "*",
    "TGT": "C", "TGC": "C", "TGA": "*", "TGG": "W",
    "CTT": "L", "CTC": "L", "CTA": "L", "CTG": "L",
    "CCT": "P", "CCC": "P", "CCA": "P", "CCG": "P",
    "CAT": "H", "CAC": "H", "CAA": "Q", "CAG": "Q",
    "CGT": "R", "CGC": "R", "CGA": "R", "CGG": "R",
    "ATT": "I", "ATC": "I", "ATA": "I", "ATG": "M",
    "ACT": "T", "ACC": "T", "ACA": "T", "ACG": "T",
    "AAT": "N", "AAC": "N", "AAA": "K", "AAG": "K",
    "AGT": "S", "AGC": "S", "AGA": "R", "AGG": "R",
    "GTT": "V", "GTC": "V", "GTA": "V", "GTG": "V",
    "GCT": "A", "GCC": "A", "GCA": "A", "GCG": "A",
    "GAT": "D", "GAC": "D", "GAA": "E", "GAG": "E",
    "GGT": "G", "GGC": "G", "GGA": "G", "GGG": "G",
}


def read_tsv(path: Path, **kwargs) -> pd.DataFrame:
    """Read a TSV or a ZIP containing one real TSV plus optional macOS metadata."""
    if path.suffix.lower() != ".zip":
        return pd.read_csv(path, sep="\t", **kwargs)
    with zipfile.ZipFile(path) as archive:
        members = [
            name for name in archive.namelist()
            if not name.endswith("/") and not name.startswith("__MACOSX/")
            and Path(name).suffix.lower() in {".tsv", ".txt", ".csv"}
        ]
        if len(members) != 1:
            raise RuntimeError(f"Expected exactly one data table in {path}, found {members}")
        with archive.open(members[0]) as raw, TextIOWrapper(raw, encoding="utf-8") as handle:
            return pd.read_csv(handle, sep="\t", **kwargs)


class UnionFind:
    def __init__(self, n: int) -> None:
        self.parent = list(range(n))

    def find(self, item: int) -> int:
        while self.parent[item] != item:
            self.parent[item] = self.parent[self.parent[item]]
            item = self.parent[item]
        return item

    def union(self, left: int, right: int) -> None:
        left, right = self.find(left), self.find(right)
        if left != right:
            self.parent[right] = left


def read_fasta(path: Path) -> list[tuple[str, str]]:
    records: list[tuple[str, str]] = []
    name: str | None = None
    parts: list[str] = []
    for raw in path.read_text(encoding="utf-8").splitlines():
        line = raw.strip()
        if not line:
            continue
        if line.startswith(">"):
            if name is not None:
                records.append((name, "".join(parts).upper()))
            name = line[1:].strip().split()[0]
            parts = []
        else:
            parts.append(re.sub(r"\s+", "", line))
    if name is not None:
        records.append((name, "".join(parts).upper()))
    if not records or len({name for name, _ in records}) != len(records):
        raise RuntimeError("FASTA must contain records with unique identifiers")
    return records


def aligned_maps(reference: str, candidate: str) -> tuple[dict[int, str], dict[int, int], int]:
    result = edlib.align(reference, candidate, mode="NW", task="path")
    alignment = edlib.getNiceAlignment(result, reference, candidate)
    reference_position = 0
    candidate_position = 0
    bases: dict[int, str] = {}
    indices: dict[int, int] = {}
    for reference_base, candidate_base in zip(
        alignment["query_aligned"], alignment["target_aligned"]
    ):
        if candidate_base != "-":
            candidate_position += 1
        if reference_base != "-":
            reference_position += 1
            bases[reference_position] = candidate_base
            if candidate_base != "-":
                indices[reference_position] = candidate_position
    return bases, indices, int(result["editDistance"])


def build_dms_reference(ncbi_reference: str, snv_table: Path) -> tuple[str, list[dict]]:
    reference = list(ncbi_reference)
    positions = read_tsv(
        snv_table,
        usecols=["genome_nt_mut_pos", "genome_nt_mut_wt"],
        low_memory=False,
    ).drop_duplicates()
    if len(positions) != GENOME_LENGTH:
        raise RuntimeError("SNV table does not define exactly one WT base per genome position")
    changes = []
    for row in positions.itertuples(index=False):
        observed = reference[int(row.genome_nt_mut_pos) - 1]
        if observed != row.genome_nt_mut_wt:
            changes.append({
                "position": int(row.genome_nt_mut_pos),
                "ncbi_reference": observed,
                "dms_reference": row.genome_nt_mut_wt,
            })
        reference[int(row.genome_nt_mut_pos) - 1] = row.genome_nt_mut_wt
    return "".join(reference), changes


def normalize_aa_table(path: Path) -> pd.DataFrame:
    frame = read_tsv(path, low_memory=False)
    frame.loc[frame["aa_mut_gene"].isin(["F", "J"]), "aa_mut_pos"] += 1
    if frame["aa_mut_ID"].duplicated().any():
        raise RuntimeError("AA lookup contains duplicate mutation identifiers")
    return frame


def build_codon_map(
    residue_map_path: Path,
    aa: pd.DataFrame,
    dms_reference: str,
) -> pd.DataFrame:
    mapping = pd.read_csv(residue_map_path)
    wild_type = aa[["aa_mut_gene", "aa_mut_pos", "aa_mut_wt"]].drop_duplicates()
    mapping = mapping.merge(
        wild_type, on=["aa_mut_gene", "aa_mut_pos"], how="inner", validate="one_to_one"
    )
    rows = []
    for row in mapping.itertuples(index=False):
        positions = tuple(int(value) for value in str(row.genome_positions).split(","))
        matches = []
        for permutation in itertools.permutations(positions):
            codon = "".join(dms_reference[position - 1] for position in permutation)
            if CODON_TABLE[codon] != row.aa_mut_wt:
                continue
            gaps = [
                (permutation[index + 1] - permutation[index]) % GENOME_LENGTH
                for index in range(2)
            ]
            matches.append((sum(gaps), max(gaps), permutation, codon))
        if not matches:
            raise RuntimeError(
                f"No DMS-reference codon matches {row.aa_mut_gene}{row.aa_mut_pos}{row.aa_mut_wt}"
            )
        _, maximum_gap, ordered_positions, codon = sorted(matches)[0]
        if maximum_gap != 1:
            raise RuntimeError(f"Non-contiguous codon mapping for {row.aa_mut_gene}{row.aa_mut_pos}")
        rows.append({
            "aa_mut_gene": row.aa_mut_gene,
            "aa_mut_pos": int(row.aa_mut_pos),
            "aa_mut_wt": row.aa_mut_wt,
            "codon_positions": ",".join(str(value) for value in ordered_positions),
            "reference_codon": codon,
        })
    return pd.DataFrame(rows)


def aggregate_fitness(values: pd.Series | np.ndarray) -> float:
    array = pd.to_numeric(pd.Series(values), errors="coerce").dropna().to_numpy(float)
    if array.size == 0:
        return np.nan
    scaled = np.clip((array + 0.5) / 1.75, 0.0, 1.0)
    return float(0.50 * np.quantile(scaled, 0.10) + 0.30 * scaled.mean() + 0.20 * scaled.min())


def event_ids(frame: pd.DataFrame) -> np.ndarray:
    union_find = UnionFind(len(frame))
    sets = [set(int(value) for value in text.split(",")) for text in frame["codon_positions"]]
    position_to_rows: dict[int, list[int]] = defaultdict(list)
    for index, positions in enumerate(sets):
        for position in positions:
            position_to_rows[position].append(index)
    for indices in position_to_rows.values():
        for index in indices[1:]:
            union_find.union(indices[0], index)
    roots = [union_find.find(index) for index in range(len(frame))]
    canonical = {root: number for number, root in enumerate(sorted(set(roots)), start=1)}
    return np.asarray([canonical[root] for root in roots], dtype=int)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--fasta", required=True, type=Path)
    parser.add_argument("--reference-fasta", required=True, type=Path)
    parser.add_argument("--snv-table", required=True, type=Path)
    parser.add_argument("--aa-table", required=True, type=Path)
    parser.add_argument("--residue-map", required=True, type=Path)
    parser.add_argument("--consequence-output", required=True, type=Path)
    parser.add_argument("--event-output", required=True, type=Path)
    parser.add_argument("--candidate-output", required=True, type=Path)
    parser.add_argument("--audit-output", required=True, type=Path)
    args = parser.parse_args()

    ncbi_reference = read_fasta(args.reference_fasta)[0][1]
    if len(ncbi_reference) != GENOME_LENGTH:
        raise RuntimeError(f"Reference FASTA must be {GENOME_LENGTH} nt")
    dms_reference, reference_differences = build_dms_reference(ncbi_reference, args.snv_table)
    aa = normalize_aa_table(args.aa_table)
    lookup = aa.set_index("aa_mut_ID")
    codons = build_codon_map(args.residue_map, aa, dms_reference)
    gene_starts = {
        gene: tuple(int(value) for value in block.loc[block["aa_mut_pos"].idxmin(), "codon_positions"].split(","))[0]
        for gene, block in codons.groupby("aa_mut_gene", sort=False)
    }

    consequence_rows = []
    audit_rows = []
    for candidate_id, sequence in read_fasta(args.fasta):
        bases, indices, edit_distance = aligned_maps(ncbi_reference, sequence)
        supported = 0
        unsupported = 0
        for row in codons.itertuples(index=False):
            positions = tuple(int(value) for value in row.codon_positions.split(","))
            if any(position not in indices or bases.get(position) not in "ACGT" for position in positions):
                unsupported += 1
                continue
            candidate_indices = [indices[position] for position in positions]
            for index in range(1, len(candidate_indices)):
                while candidate_indices[index] <= candidate_indices[index - 1]:
                    candidate_indices[index] += len(sequence)
            if np.diff(candidate_indices).tolist() != [1, 1]:
                unsupported += 1
                continue
            start_index = indices.get(gene_starts[row.aa_mut_gene])
            if start_index is None:
                unsupported += 1
                continue
            while candidate_indices[0] < start_index:
                candidate_indices[0] += len(sequence)
            if (candidate_indices[0] - start_index) % 3 != 0:
                unsupported += 1
                continue
            candidate_codon = "".join(bases[position] for position in positions)
            alternate = CODON_TABLE[candidate_codon]
            if alternate == row.aa_mut_wt:
                continue
            mutation_id = f"gp{row.aa_mut_gene}_{row.aa_mut_wt}{row.aa_mut_pos}{alternate}"
            if mutation_id not in lookup.index:
                unsupported += 1
                continue
            measured = lookup.loc[mutation_id]
            supported += 1
            consequence_rows.append({
                "candidate_id": candidate_id,
                "aa_mut_ID": mutation_id,
                "aa_mut_gene": row.aa_mut_gene,
                "aa_mut_pos": int(row.aa_mut_pos),
                "aa_mut_wt": row.aa_mut_wt,
                "aa_mut_sub": alternate,
                "aa_mut_class": measured["aa_mut_class"],
                "codon_positions": row.codon_positions,
                "reference_codon_dms": row.reference_codon,
                "candidate_codon": candidate_codon,
                "fitness_aa_experimental": float(measured["fitness_aa_mut"]),
                "sem_aa_experimental": float(measured["sem_aa_mut"]),
                "phix_aa_mut_orf_class": measured["phix_aa_mut_orf_class"],
            })
        audit_rows.append({
            "candidate_id": candidate_id,
            "candidate_length": len(sequence),
            "edit_distance_to_ncbi_reference": edit_distance,
            "supported_aa_consequences": supported,
            "unsupported_or_frame_disrupted_residues": unsupported,
        })

    consequences = pd.DataFrame(consequence_rows)
    if consequences.empty:
        raise RuntimeError("No candidate amino-acid consequences were supported")
    event_frames = []
    for candidate_id, block in consequences.groupby("candidate_id", sort=False):
        block = block.copy().reset_index(drop=True)
        block["aa_event_local"] = event_ids(block)
        block["aa_event_id"] = block["candidate_id"] + ":" + block["aa_event_local"].astype(str)
        event_frames.append(block)
    consequences = pd.concat(event_frames, ignore_index=True)

    events = (
        consequences.groupby(["candidate_id", "aa_event_id"], as_index=False)
        .agg(
            aa_event_experimental_fitness=("fitness_aa_experimental", "min"),
            consequence_count=("aa_mut_ID", "size"),
            genes=("aa_mut_gene", lambda values: "|".join(sorted(set(values)))),
            mutation_ids=("aa_mut_ID", lambda values: "|".join(sorted(set(values)))),
            genome_positions=(
                "codon_positions",
                lambda values: ",".join(
                    str(position)
                    for position in sorted({
                        int(position)
                        for text in values
                        for position in str(text).split(",")
                    })
                ),
            ),
        )
    )
    candidates = (
        events.groupby("candidate_id", as_index=False)
        .agg(
            aa_event_count=("aa_event_id", "size"),
            aa_fitness_experimental=("aa_event_experimental_fitness", aggregate_fitness),
            aa_event_min_fitness=("aa_event_experimental_fitness", "min"),
            aa_event_mean_fitness=("aa_event_experimental_fitness", "mean"),
        )
    )
    audit = pd.DataFrame(audit_rows).merge(candidates, on="candidate_id", how="left", validate="one_to_one")

    for path in [args.consequence_output, args.event_output, args.candidate_output, args.audit_output]:
        path.parent.mkdir(parents=True, exist_ok=True)
    consequences.to_csv(args.consequence_output, index=False, compression="gzip")
    events.to_csv(args.event_output, index=False, compression="gzip")
    candidates.to_csv(args.candidate_output, index=False)
    audit_payload = {
        "candidate_count": int(len(audit)),
        "consequence_rows": int(len(consequences)),
        "event_rows": int(len(events)),
        "candidates_with_aa_events": int(candidates["candidate_id"].nunique()),
        "reference_differences_ncbi_vs_dms": reference_differences,
        "supported_aa_consequence_min": int(audit["supported_aa_consequences"].min()),
        "supported_aa_consequence_median": float(audit["supported_aa_consequences"].median()),
        "supported_aa_consequence_max": int(audit["supported_aa_consequences"].max()),
        "unsupported_residue_median": float(audit["unsupported_or_frame_disrupted_residues"].median()),
    }
    args.audit_output.write_text(json.dumps(audit_payload, indent=2, sort_keys=True), encoding="utf-8")
    print(
        "PHIX_TRACE_AA_CANDIDATE_ANNOTATION_PASS "
        f"candidates={len(audit)} consequences={len(consequences)} events={len(events)}"
    )


if __name__ == "__main__":
    main()
