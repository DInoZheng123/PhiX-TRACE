# PhiX-TRACE Genome v4.1.1 — FASTA scoring notebook

This lightweight package is the end-user companion to the final v7 PhiX-TRACE Genome submission package. It is for researchers who want to score new PhiX174 candidate genomes without retraining the model. The only user-supplied scientific input is a FASTA file.

## Quick start

1. Replace `user_input/candidate_genomes.fasta` with your multi-FASTA file.
2. Open `RUN_ME_FASTA_SCORING.ipynb`.
3. Select a Python 3.12 kernel.
4. Choose **Restart Kernel and Run All Cells**.

The notebook shows the final v7 workflow diagram, installs missing pinned dependencies, validates the package inputs, scores every FASTA record, displays the main result table, and writes machine-readable outputs under `user_output/`.

## Output

The main file is `user_output/candidate_complete_scores.csv`. For each candidate it contains:

- raw coding-event fitness (`C`);
- raw noncoding fitness (`N`);
- critical-protein integrity (`P`);
- noncoding integrity (`R`);
- architecture integrity (`A`);
- frozen Science-302 percentiles for all available components;
- weighted component contributions;
- the final PhiX-TRACE genome score;
- an input-local rank and validity status.

The score is calculated as:

```text
0.45 × C + 0.15 × N + 0.25 × P + 0.10 × R + 0.05 × A
```

Here `C`, `N`, `P`, `R` and `A` in the weighted formula are the component percentiles frozen against the released Science-302 reference cohort. If a fitness component is unavailable, the scorer reports the missing value and renormalizes over available component weights; coverage diagnostics remain in the output.

The five raw components have these biological meanings: `C` summarizes coding-event fitness, `N` summarizes noncoding SNV fitness, `P` tests seven critical translated proteins, `R` tests the 206 reference noncoding sites, and `A` checks the circular start/stop architecture. The final v7 workflow diagram is included under `publication_assets/Figure_1/` for reference.

Additional files are:

- `candidate_complete_raw_components.csv`: raw components and coverage diagnostics;
- `candidate_complete_snv_details.csv.gz`: supported SNV-level evidence;
- `complete_scoring_audit.json`: input checksum, scope and validity summary.

## Required FASTA format

- one or more records with unique identifiers;
- DNA alphabet `A`, `C`, `G`, `T` (ambiguous `N` is accepted but causes a partial status);
- expected length: 5,386 nt;
- forward orientation;
- the same coordinate origin as PhiX174 NC_001422.1.

## Important scope restriction

This package is valid only for PhiX174 candidates compatible with NC_001422.1. It is not a general phage-scoring model and must not be used for unrelated phage species. Indels, length changes and ambiguous bases yield partial results that require manual review because the coding and noncoding fitness evidence is SNV-based.

The final score is a cohort-referenced research prioritization score, not a calibrated probability of viability.

## Command-line alternative

```bash
python -m pip install -r requirements.txt
bash score_fasta.sh user_input/candidate_genomes.fasta
```

## Included frozen resources

The package contains the reference sequence and annotation, the released 16,098-SNV prediction lookup, the frozen Science-302 component calibration, the original Wei nucleotide and amino-acid fitness tables needed by the scorer, the residue-to-genome map and the final v7 workflow diagram. Model training and manuscript Figures 2–4 are intentionally not included; use the separate full reproduction package for those tasks.
